package com.rekcode.yahtzee.api

/**
 * ============================================================
 * API SURFACE LOCK — DO NOT MODIFY WITHOUT VERSION BUMP
 * ============================================================
 *
 * PURPOSE:
 * This file enforces a compile-time contract for the public API.
 *
 * If any of these signatures change, the build will fail,
 * forcing a conscious version update.
 *
 * This protects:
 * - Binary compatibility
 * - External consumers
 * - Published artifacts (JAR / Maven)
 *
 * RULES:
 * - Only reference PUBLIC API types here
 * - DO NOT use internal/game package types
 * - Update ONLY when intentionally changing API
 *
 * VERSION: 1.0.0
 */
@Suppress("unused")
internal object ApiSurfaceLock {

    // ========================================================
    // Factory
    // ========================================================

    val createGameRef: (Int) -> YahtzeeGame = ::createGame

    // ========================================================
    // Core Game Actions
    // ========================================================

    val rollDiceRef: (YahtzeeGame) -> Unit = { it.rollDice() }
    val scoreRef: (YahtzeeGame, ScoreCategory) -> Unit = { g, c -> g.score(c) }
    val nextPlayerRef: (YahtzeeGame) -> Unit = { it.nextPlayer() }

    // ========================================================
    // Game State
    // ========================================================

    val getCurrentPlayerIndexRef: (YahtzeeGame) -> Int = { it.getCurrentPlayerIndex() }
    val getCurrentDiceRef: (YahtzeeGame) -> List<Int> = { it.getCurrentDice() }
    val canRollRef: (YahtzeeGame) -> Boolean = { it.canRoll() }
    val hasRolledRef: (YahtzeeGame) -> Boolean = { it.hasRolled() }
    val getRollsRemainingRef: (YahtzeeGame) -> Int = { it.getRollsRemaining() }

    val isGameOverRef: (YahtzeeGame) -> Boolean = { it.isGameOver() }
    val getWinnerIndexRef: (YahtzeeGame) -> Int? = { it.getWinnerIndex() }

    val getPlayerCountRef: (YahtzeeGame) -> Int = { it.getPlayerCount() }
    val getPlayerFinalScoreRef: (YahtzeeGame, Int) -> Int =
        { g, i -> g.getPlayerFinalScore(i) }

    // ========================================================
    // Score Sheet
    // ========================================================

    val getScoreSheetRef: (YahtzeeGame, Int) -> List<ScoreSheetItem> =
        { g, i -> g.getScoreSheet(i) }

    // ========================================================
    // Bonus Status
    // ========================================================

    val getUpperSectionBonusStatusRef: (YahtzeeGame, Int) -> UpperBonusStatus =
        { g, i -> g.getUpperSectionBonusStatus(i) }
}