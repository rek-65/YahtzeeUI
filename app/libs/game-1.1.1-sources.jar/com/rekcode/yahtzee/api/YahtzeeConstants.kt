package com.rekcode.yahtzee.api

/**
 * Public API constants for the Yahtzee game engine.
 *
 * These constants are part of the stable public API contract and are
 * intended for use by all consumers of the engine, including UI layers,
 * test harnesses, and external integrations.
 *
 * API CONTRACT RULES:
 * - These values must never change without a version bump
 * - Do NOT add internal engine details here
 * - Only expose values that consumers genuinely need
 */
object YahtzeeConstants {

    // --- Upper Section Bonus ---

    /** Minimum upper section score required to earn the bonus */
    const val UPPER_BONUS_THRESHOLD = 63

    /** Bonus points awarded for reaching the upper section threshold */
    const val UPPER_BONUS_AMOUNT = 35

    // --- Fixed Category Scores ---

    /** Fixed score awarded for a Full House */
    const val FULL_HOUSE_SCORE = 25

    /** Fixed score awarded for a Small Straight */
    const val SMALL_STRAIGHT_SCORE = 30

    /** Fixed score awarded for a Large Straight */
    const val LARGE_STRAIGHT_SCORE = 40

    /** Fixed score awarded for a Yahtzee */
    const val YAHTZEE_SCORE = 50

    /** Bonus points awarded for each additional Yahtzee beyond the first */
    const val YAHTZEE_BONUS_PER_EXTRA = 100
}