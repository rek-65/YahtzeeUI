package com.rekcode.yahtzee.game

import com.rekcode.yahtzee.api.UpperBonusStatus

/**
 * Utility functions for score sheet operations.
 *
 * All functions are pure:
 * - No side effects
 * - No mutation of game state
 * - Deterministic output
 *
 * These utilities support preview, simulation, and delta
 * calculations without affecting live game state.
 */

/**
 * Creates a new empty score sheet.
 *
 * Each [ScoreCategory] is initialized with an unlocked [ScoreEntry]
 * containing a null score.
 *
 * @return MutableMap of [ScoreCategory] to empty [ScoreEntry]
 */
internal fun createEmptyScoreSheet(): MutableMap<ScoreCategory, ScoreEntry> {
    return ScoreCategory.entries.associateWith {
        ScoreEntry()
    }.toMutableMap()
}

/**
 * Returns a preview score for a single category based on current dice.
 *
 * @param category The category being evaluated
 * @param dice Current dice values
 * @param scoreSheet Current score sheet state
 *
 * @return The calculated score, or null if the category is already locked
 */
internal fun previewScore(
    category: ScoreCategory,
    dice: List<Int>,
    scoreSheet: Map<ScoreCategory, ScoreEntry>
): Int? {
    val entry = scoreSheet[category]

    // Already scored → no preview
    if (entry?.locked == true) return null

    return calculateScore(category, dice)
}

/**
 * Returns preview scores for all categories.
 *
 * Locked categories return null.
 *
 * @param dice Current dice values
 * @param scoreSheet Current score sheet state
 *
 * @return Map of [ScoreCategory] to preview score (null if locked)
 */
internal fun previewAllScores(
    dice: List<Int>,
    scoreSheet: Map<ScoreCategory, ScoreEntry>
): Map<ScoreCategory, Int?> {
    return ScoreCategory.entries.associateWith { category ->
        previewScore(category, dice, scoreSheet)
    }
}

/**
 * Calculates the TOTAL score impact of assigning a category,
 * including bonuses (upper bonus, Yahtzee bonus).
 *
 * This function does NOT mutate the actual player state.
 *
 * @param category The category being evaluated
 * @param dice Current dice values
 * @param player The current player state
 *
 * @return Simulated total score after applying this move, or null if invalid
 */
internal fun previewScoreWithBonuses(
    category: ScoreCategory,
    dice: List<Int>,
    player: PlayerState
): Int? {
    val entry = player.scoreSheet[category]

    // Already locked → no preview
    if (entry?.locked == true) return null

    val baseScore = calculateScore(category, dice)

    // --- Simulated score sheet ---
    val simulatedSheet = player.scoreSheet.toMutableMap()
    simulatedSheet[category] = ScoreEntry(baseScore, true)

    // --- Simulated player (no mutation of real state) ---
    val simulatedPlayer = PlayerState().apply {
        loadScoreSheet(simulatedSheet)
        extraYahtzees = player.extraYahtzees
    }

    return baseScore
}

/**
 * Returns the delta between current score and previewed score.
 *
 * Useful for AI decisions or UI highlighting.
 *
 * @param category The category being evaluated
 * @param dice Current dice values
 * @param player The current player state
 *
 * @return Score difference, or null if preview is invalid
 */
internal fun previewScoreDelta(
    category: ScoreCategory,
    dice: List<Int>,
    player: PlayerState
): Int? {
    val previewTotal = previewScoreWithBonuses(category, dice, player)
        ?: return null

    val currentTotal = player.finalScore()

    return previewTotal - currentTotal
}

/**
 * Returns the current Upper Section Bonus status for a player.
 *
 * Evaluates the player's current upper section score against
 * [YahtzeeConstants.UPPER_BONUS_THRESHOLD] and returns a complete
 * status summary without modifying any game state.
 *
 * @param player The current player state
 *
 * @return [UpperBonusStatus] containing current score, threshold,
 *         bonus amount, achievement status, and points still needed
 */
internal fun getUpperSectionBonusStatus(player: PlayerState): UpperBonusStatus {
    val current = player.upperSectionScore()
    return UpperBonusStatus(
        currentScore = current,
        threshold = YahtzeeConstants.UPPER_BONUS_THRESHOLD,
        bonusAmount = if (current >= YahtzeeConstants.UPPER_BONUS_THRESHOLD)
            YahtzeeConstants.UPPER_BONUS_AMOUNT else 0,
        achieved = current >= YahtzeeConstants.UPPER_BONUS_THRESHOLD,
        pointsNeeded = if (current >= YahtzeeConstants.UPPER_BONUS_THRESHOLD)
            0 else YahtzeeConstants.UPPER_BONUS_THRESHOLD - current
    )
}